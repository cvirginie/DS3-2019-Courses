import numpy as np

def mlp_function(X):
    w1 = np.loadtxt('weights/W1.txt')
    w2 = np.loadtxt('weights/W2.txt')
    w3 = np.loadtxt('weights/W3.txt')

    assert X.shape[1] == w1.shape[0]

    l1 = np.matmul(X, w1)
    l1 = l1*(l1 > 0)
    l2 = np.matmul(l1, w2)
    l2 = l2*(l2 > 0)
    out = -np.matmul(l2, w3)
    return out


def fn(low,high,x):
    a = np.zeros_like(low)
    b= np.zeros_like(high)
    for i in range(low.shape[0]):
        for j in range(low.shape[1]):
            a[i,j] = sum([0.5**k for k in range(1, int(low[i,j])+1)])
            b[i,j] = sum([0.5**k for k in range(1, int(high[i, j])+1)])
    y =  (1/(b-a))*(1-(1/(b-a))*4*np.abs(x-((a+b)/2)))
    y[y<0] = 0
    return y

def mysterious_function(X, seed):
	np.random.seed(seed)
	rnd = np.random.randint(low=5, high=15)
    low = np.floor(np.log(1-X)/np.log(0.5))
    low[low > rnd] = rnd
    high = np.ceil(np.log(1-X)/np.log(0.5))
    high[high > rnd+1] = rnd+1
    Y = fn(low, high, X)
    if len(Y.shape) == 1:
        return Y
    else:
        return np.max(Y, axis=1)

if __name__ == '__main__':
    X = np.random.rand(10,4)
    y = mysterious_function(X)
    print(X)
    print(y)

