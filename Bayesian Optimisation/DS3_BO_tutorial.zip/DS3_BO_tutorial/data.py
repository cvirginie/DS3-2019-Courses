import numpy as np
import numpy.random as rnd


def generate_gp(nb=100, noise=1.0, rng=[-10, 10], x0=[-9, -6, 1, 5, 11], w=2.0, scale=1e-4):
    x = rnd.rand(nb)*(rng[1]-rng[0]) + rng[0]
    y = scale*np.ones_like(x)
    for xx0 in x0:
        y *= x-xx0
    y *= np.sin(w*x)
    y += noise*rnd.randn(nb)
    return np.reshape(x, [-1,1]), np.reshape(y, [-1,1])


def function1(x0=[1, 5, 7, 11], scale=1):
    def fn(x):
        y = scale*np.ones_like(x)
        for xx0 in x0:
            y *= x-xx0
        return y
    return fn


def function2(x0=[-9, -6, 1, 5, 11], w=2.0, scale=1e-4):
    def fn(x):
        y = scale*np.ones_like(x)
        for xx0 in x0:
            y *= x-xx0
        y *= np.sin(w*x)
        return np.reshape(y, [-1,1])
    return fn


def function3(w=1.0, k=1.0):
    def fn(x):
        tr =  w*(1- w*np.abs(x - (2*k+1)*np.pi))
        tr[tr<0] = 0
        y = -(np.cos(x) + tr)
        return y
    return fn


def function4(noise=1.0):
    return lambda x,y: noise*np.random.randn(y.shape[0],1)*np.round(x) + np.exp(-y**2)*np.round(1-x)