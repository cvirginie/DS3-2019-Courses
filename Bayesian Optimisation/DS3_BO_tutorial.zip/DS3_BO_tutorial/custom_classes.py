import numpy as np
from gpflowopt.domain import Domain, ContinuousParameter

class MyCube(Domain):
    """
    The domain [a, b]^d
    """
    def __init__(self, bounds = [0, 1], n_inputs=1):
        params = [ContinuousParameter('u{0}'.format(i), bounds[0], bounds[1]) for i in np.arange(n_inputs)]
        super(MyCube, self).__init__(params)
        
        
