import numpy as np
from  sklearn import datasets, svm
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

def get_data(train, val):
    assert train+val < 1.0
    digits = datasets.load_digits()
    X_digits = digits.data
    y_digits = digits.target
    n_sample = len(X_digits)
    n_train = int(train*n_sample)
    n_val = int(val*n_sample)
    idx = np.random.permutation(n_sample)
    train_data = (X_digits[idx[:n_train]], y_digits[idx[:n_train]])
    val_data =  (X_digits[idx[n_train:n_train+n_val]], y_digits[idx[n_train:n_train+n_val]])
    test_data = (X_digits[idx[n_train+n_val:]], y_digits[idx[n_train+n_val:]])
    return train_data, val_data, test_data


def grid_search(bounds):
    train, val, test = get_data(0.7, 0.1)
    """
	Write grid search, return GridSearchCV object and obtained test accuracy
    """
    return clf, test_acc

def random_search(dists):
    train, val, test = get_data(0.7, 0.1)
    """
	Write random search, return RandomizedSearchCV object and obtained test accuracy
    """
    return clf, test_acc


def train_predict(C, gamma, train, val, test):
    svc = svm.SVC(C=C, gamma=gamma)
    svc.fit(train[0], train[1])
    val_acc = svc.score(val[0], val[1])
    test_acc = svc.score(test[0], test[1])
    return 1-val_acc, test_acc


