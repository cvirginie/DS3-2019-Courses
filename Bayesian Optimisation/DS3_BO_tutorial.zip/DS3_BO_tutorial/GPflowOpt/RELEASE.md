# Release 0.1.0
Initial release of GPflowOpt

# Release 0.1.1
Small bugfix release
