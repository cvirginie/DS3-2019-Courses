.. GPflowOpt documentation master file, created by
   sphinx-quickstart on Sun Apr 30 20:34:41 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GPflowOpt Documentation
=====================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   intro
   tutorialsAndExamples
   apiAndArchitecture
