.. _tutorials:

Tutorials and examples
==================================

.. toctree::
   :maxdepth: 2

   notebooks/firststeps
   notebooks/constrained_bo
   notebooks/new_acquisition
   notebooks/hyperopt
   notebooks/multiobjective
