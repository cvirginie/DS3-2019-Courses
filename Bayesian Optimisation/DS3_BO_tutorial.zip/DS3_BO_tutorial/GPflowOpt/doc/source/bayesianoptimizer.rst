Bayesian Optimizer
==================

.. automodule:: gpflowopt.bo
.. autoclass:: gpflowopt.BayesianOptimizer
   :members:
   :special-members:
