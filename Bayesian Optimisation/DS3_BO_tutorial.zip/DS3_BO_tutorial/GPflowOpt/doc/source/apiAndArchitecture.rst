.. _api:

API and architecture
==================================

.. toctree::
   :maxdepth: 1

   notebooks/structure
   bayesianoptimizer
   acquisition
   designs
   transforms
   interfaces
