Data Transformations
====================

Transforms
----------
.. automodule:: gpflowopt.transforms
.. autoclass:: gpflowopt.transforms.LinearTransform
   :special-members:

Normalizer
----------
.. automodule:: gpflowopt.scaling
.. autoclass:: gpflowopt.scaling.DataScaler
